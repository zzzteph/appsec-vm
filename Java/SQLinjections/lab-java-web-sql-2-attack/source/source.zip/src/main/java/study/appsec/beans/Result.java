package study.appsec.beans;





public class Result
{
    String status="";
    String result="";

    public Result(String status, String result)
    {
        this.status=status;
        this.result=result;
    }

}

