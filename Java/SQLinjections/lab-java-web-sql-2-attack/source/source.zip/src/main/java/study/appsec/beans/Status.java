package study.appsec.beans;





public class Status
{
    String status="";
    String modifier="";

    public Status(String status, String modifier)
    {
        this.status=status;
        this.modifier=modifier;
        
    }

}

