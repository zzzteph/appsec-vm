package appsec.study.rce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RceApplicationTests {

	@Test
	void contextLoads() {
	}

}
