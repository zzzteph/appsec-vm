package appsec.study.rce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RceApplication.class, args);
	}

}
