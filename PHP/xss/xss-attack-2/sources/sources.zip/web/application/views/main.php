<p>Yes, I am a criminal.  My crime is that of curiosity.  My crime is that of judging people by what they say and think, not what they look like. My crime is that of outsmarting you, something that you will never forgive me for.</p>

 <p>       I am a hacker,  you may stop this individual,but you can't stop us all... after all, we're all alike.</p>


<p> Register and speak with me</p>