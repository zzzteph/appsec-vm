

<?php

include('include.php');

?>
  
  <section class="section">
    <div class="container">
      <h1 class="title">
       Secure Virtual GNU
      </h1>
      <p class="subtitle">
        This is my implementation of GNU tools!
      </p>
    </div>

	
	
	
  </section>
  </body>
</html>