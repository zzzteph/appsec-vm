<?php

include('include.php');

?>
  
  
  <section class="section">
    <div class="container">
      <h1 class="title">
      Under construction
      </h1>
      <p class="subtitle">
        Tools will be released in next month, all got from the system.
      </p>
	  
	  <p>
	I try to implement secure command realization from my <code>/bin/</code> folder. Currently I got ping, wget,find and some other commands that are under development.
	  
	  </p>
	  
    </div>


  </section>
  </body>
</html>